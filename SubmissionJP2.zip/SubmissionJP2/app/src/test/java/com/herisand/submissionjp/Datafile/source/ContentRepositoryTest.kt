package com.herisand.submissionjp.Datafile.source

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.herisand.submissionjp.Datafile.source.remote.RemoteDataSource
import com.herisand.submissionjp.utils.DataDummy
import com.herisand.submissionjp.utils.LiveDataTestUtil
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.verify
import com.nhaarman.mockitokotlin2.doAnswer
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito.mock



class ContentRepositoryTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = mock(RemoteDataSource::class.java)
    private val contentRepository = FakeContentRepository(remote)
    private val tvData = DataDummy.generateRemoteDummyTv()
    private val movieData = DataDummy.generateDataMovie()

    @Test
    fun getAllTvShows() {
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadTvShowCallback)
                .onAllTvShowsReceived(tvData)
            null
        }.`when`(remote).getAllTv(any())
        val tvEntity = LiveDataTestUtil.getValue(contentRepository.getAllTvShows())
        verify(remote).getAllTv(any())
        assertNotNull(tvEntity)
        assertEquals(tvData.size.toLong(), tvEntity.size.toLong())
    }

    @Test
    fun getAllMovies() {
        doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadMovieCallback)
                .onAllMoviesReceived(movieData)
            null
        }.`when`(remote).getAllMovie(any())
        val movieEntities = LiveDataTestUtil.getValue(contentRepository.getAllMovies())
        verify(remote).getAllMovie(any())
        assertNotNull(movieData)
        assertEquals(movieData.size.toLong(), movieEntities.size.toLong())

    }
}