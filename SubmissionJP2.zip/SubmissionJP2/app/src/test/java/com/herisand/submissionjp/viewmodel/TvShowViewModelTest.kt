package com.herisand.submissionjp.viewmodel


import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.herisand.submissionjp.Datafile.source.ContentRepository
import com.herisand.submissionjp.Datafile.source.remote.response.TvData
import com.herisand.submissionjp.utils.DataDummy
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner


@RunWith(MockitoJUnitRunner::class)
class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var contentRepository: ContentRepository

    @Mock
    private lateinit var observer: Observer<List<TvData>>

    @Before
    fun setTvShow(){
        viewModel = TvShowViewModel(contentRepository)
    }

    @Test
    fun getTvShow() {
        val dummyData = DataDummy.generateDataTv()
        val tvShows = MutableLiveData<List<TvData>>()
        tvShows.value = dummyData

        `when`(contentRepository.getAllTvShows()).thenReturn(tvShows)
        val tvShowEntities = viewModel.getTvShow().value
        verify(contentRepository).getAllTvShows()
        assertNotNull(tvShows)
        assertEquals(20, tvShowEntities?.size)

        viewModel.getTvShow().observeForever(observer)
        verify(observer).onChanged(dummyData)
    }

}