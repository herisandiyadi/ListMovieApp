//package com.herisand.submissionjp.viewmodel
//
//import androidx.arch.core.executor.testing.InstantTaskExecutorRule
//import androidx.lifecycle.MutableLiveData
//import androidx.lifecycle.Observer
//import com.herisand.submissionjp.Datafile.source.ContentRepository
//import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
//import com.herisand.submissionjp.Datafile.source.remote.response.TvData
//import com.herisand.submissionjp.resources.Resource
//import com.herisand.submissionjp.utils.DataDummy
//import com.nhaarman.mockitokotlin2.verify
//import org.junit.Assert.assertEquals
//import org.junit.Assert.assertNotNull
//import org.junit.Before
//import org.junit.Rule
//import org.junit.Test
//import org.junit.runner.RunWith
//import org.mockito.Mock
//import org.mockito.Mockito.`when`
//import org.mockito.junit.MockitoJUnitRunner
//
//@RunWith(MockitoJUnitRunner::class)
//class DetailViewModelTest{
//
//    private lateinit var viewModel: DetailViewModel
//    private val dummyMovie = DataDummy.generateDataMovie()[0]
//    private val dummyTv = DataDummy.generateDataTv()[0]
//    private val movieId = dummyMovie.id
//    private val tvShowId = dummyTv.id
//
//    @get:Rule
//    var instantTaskExecutorRule = InstantTaskExecutorRule()
//
//    @Mock
//    private lateinit var contentRepository: ContentRepository
//
//    @Mock
//    private lateinit var movieObserver: Observer<Resource<MovieData>>
//
//    @Mock
//    private lateinit var tvObserver: Observer<Resource<TvData>>
//
//    @Before
//    fun setUp() {
//        viewModel = DetailViewModel(contentRepository)
//        viewModel.setSelectedContent(movieId)
//        viewModel.setSelectedContent(tvShowId)
//    }
//
//    @Test
//    fun getMovie() {
//        val dummyMovieDetail = Resource.success(DataDummy.generateDataMovie()[0])
//        val movie = MutableLiveData<Resource<MovieData>>()
//        movie.value = dummyMovieDetail
//        `when` (contentRepository.getAllMovies(movieId)).thenReturn(movie)
//        `when`(contentRepository.getAllMovies())
//        val movieEntity = viewModel.getMovie().value  as MovieData
//        verify(contentRepository).getAllMovies()
//        assertNotNull(movieEntity)
//        assertEquals(dummyMovie.id, movieEntity.id)
//        assertEquals(dummyMovie.image, movieEntity.image)
//        assertEquals(dummyMovie.description, movieEntity.description)
//        assertEquals(dummyMovie.scores, movieEntity.scores)
//        assertEquals(dummyMovie.title, movieEntity.title)
//        assertEquals(dummyMovie.background, movieEntity.background)
//        assertEquals(dummyMovie.year, movieEntity.year)
//
//        viewModel.getMovie().observeForever(movieObserver)
//        verify(movieObserver).onChanged()
//    }
//
//    @Test
//    fun setSelectedItem() {
//        assertNotNull(selectedMovie)
//        assertNotNull(selectedTv)
//    }
//
////    @Test
////    fun getTv() {
////        viewModel.setSelectedItem(selectedTv)
////        val tvData = viewModel.getTv()
////        assertNotNull(dataTv)
////        assertEquals(dataTv.id, tvData.id)
////        assertEquals(dataTv.year, tvData.year)
////        assertEquals(dataTv.title, tvData.title)
////        assertEquals(dataTv.image, tvData.image)
////        assertEquals(dataTv.description, tvData.description)
////    }
////
////    @Test
////    @Throws(UninitializedPropertyAccessException::class)
////    fun getMovieNotExist() {
////        viewModel.setSelectedItem(selectedMovieNotExist)
////        thrown.expect(UninitializedPropertyAccessException::class.java)
////        val movieData = viewModel.getMovie()
////        assertNotNull(movieData)
////        assertEquals(dataMovie.id, movieData.id)
////    }
////
////    @Test
////    @Throws(UninitializedPropertyAccessException::class)
////    fun getTvNotExist() {
////        viewModel.setSelectedItem(selectedTvNotExist)
////        thrown.expect(UninitializedPropertyAccessException::class.java)
////        val tvData = viewModel.getTv()
////        assertNotNull(tvData)
////        assertEquals(dataMovie.id, tvData.id)
////    }
//
//}