package com.herisand.submissionjp.ui.detail

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.herisand.submissionjp.Datafile.source.remote.response.TvData
import com.herisand.submissionjp.databinding.ContentDetailBinding

class DetailTVAdapter: RecyclerView.Adapter<DetailTVAdapter.ViewHolder>() {

    private val detailTv = ArrayList<TvData>()

    fun setTv(tvShows: List<TvData>?) {
        if (tvShows == null) return
        this.detailTv.clear()
        this.detailTv.addAll(tvShows)
    }

    inner class ViewHolder(private val binding: ContentDetailBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(tvData: TvData) {
            binding.tvTitleDetail.text = tvData.title
//            binding.tvYearDetail.text = tvData.year
//            binding.tvGenreDetail.text = tvData.genre
            binding.tvDescriptionDetail.text = tvData.description

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val contentDetailBinding = ContentDetailBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(contentDetailBinding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tvShow = detailTv[position]
        holder.bind(tvShow)
    }

    override fun getItemCount(): Int = detailTv.size

}