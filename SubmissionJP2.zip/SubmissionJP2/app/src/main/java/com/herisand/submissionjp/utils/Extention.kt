package com.herisand.submissionjp.utils


fun String.year(): String{
    return this.substring(0, 4)
}