package com.herisand.submissionjp.ui.detail

import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.herisand.submissionjp.Datafile.source.remote.response.TvData
import com.herisand.submissionjp.databinding.ActivityDetailTvBinding
import com.herisand.submissionjp.databinding.ContentDetailBinding
import com.herisand.submissionjp.utils.ApiConfig
import com.herisand.submissionjp.utils.year
import com.herisand.submissionjp.viewmodel.DetailViewModel
import com.herisand.submissionjp.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.activity_detail_movie.bg_img


class DetailTvActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TV = "extra_tv"
    }

    private lateinit var detailBinding: ContentDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val activityDetailTvBinding = ActivityDetailTvBinding.inflate(layoutInflater)
        detailBinding = activityDetailTvBinding.detailTvContent
        setContentView(activityDetailTvBinding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance(this)
        val viewModelTV = ViewModelProvider(this, factory)[DetailViewModel::class.java]

        val extras = intent.extras
        extras?.let {
            val data = extras.getParcelable<TvData>(EXTRA_TV)
            data?.let {
                activityDetailTvBinding.progressBar.visibility = View.VISIBLE
                activityDetailTvBinding.content.visibility = View.INVISIBLE
                viewModelTV.getTvShow().observe(this, {tvs ->
                    activityDetailTvBinding.progressBar.visibility = View.GONE
                    activityDetailTvBinding.content.visibility = View.VISIBLE

                })
                viewModelTV.getTvShow().observe(this, {tvShow -> populateTvShow(it)})
            }
        }

    }

    private fun populateTvShow(tvData: TvData) {
        detailBinding.tvTitleDetail.text = tvData.title
        detailBinding.tvYearDetail.text = tvData.year.year()
        detailBinding.tvDescriptionDetail.text = tvData.description
        supportActionBar?.title = tvData.title
        detailBinding.ratDetail.rating = (tvData.scores.div(2)).toFloat()

        Glide.with(this)
            .load(ApiConfig.IMG_URL + tvData.background)
            .centerCrop()
            .into(bg_img)

        Glide.with(this)
            .load(ApiConfig.IMG_URL + tvData.image)
            .transform(RoundedCorners(20))
            .into(detailBinding.imgDetail)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return super.onOptionsItemSelected(item)
    }

}