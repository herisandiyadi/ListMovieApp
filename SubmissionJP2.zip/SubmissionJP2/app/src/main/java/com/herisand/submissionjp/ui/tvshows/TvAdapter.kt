package com.herisand.submissionjp.ui.tvshows

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.herisand.submissionjp.Datafile.source.remote.response.TvData
import com.herisand.submissionjp.databinding.ItemsTvshowsBinding
import com.herisand.submissionjp.ui.detail.DetailTvActivity
import com.herisand.submissionjp.ui.detail.DetailTvActivity.Companion.EXTRA_TV
import com.herisand.submissionjp.utils.ApiConfig
import com.herisand.submissionjp.utils.year


class TvAdapter: RecyclerView.Adapter<TvAdapter.ListViewHolder>() {
    private var listTvShow = ArrayList<TvData>()

    fun setTvShow(tvShows: List<TvData>?) {
        if (tvShows == null) return
        this.listTvShow.clear()
        this.listTvShow.addAll(tvShows)
    }

    class ListViewHolder(private val binding: ItemsTvshowsBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(tvData : TvData) {
            with(binding) {
                Log.d("TVDATA", tvData.toString())
                tvTitletv.text = tvData.title
                tvYeartv.text = tvData.year.year()
                ratTv.rating = (tvData.scores.div(2)).toFloat()
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailTvActivity::class.java)
                    intent.putExtra(EXTRA_TV, tvData)
                    itemView.context.startActivity(intent)
                }

                Glide.with(itemView.context)
                        .load(ApiConfig.IMG_URL + tvData.image)
                        .apply(RequestOptions().override(220, 330))
                        .into(binding.imgPostertv)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val itemsTvshowsBinding = ItemsTvshowsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(itemsTvshowsBinding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val tvshows = listTvShow[position]
        holder.bind(tvshows)
    }

    override fun getItemCount(): Int = listTvShow.size
}