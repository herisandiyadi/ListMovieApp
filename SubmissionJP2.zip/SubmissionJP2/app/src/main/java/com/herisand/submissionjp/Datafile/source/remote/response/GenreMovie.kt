package com.herisand.submissionjp.Datafile.source.remote.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class GenreMovie(
    var id: Int,
    var name: String
):Parcelable
