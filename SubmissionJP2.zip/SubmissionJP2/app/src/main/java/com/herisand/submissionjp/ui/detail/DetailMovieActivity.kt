package com.herisand.submissionjp.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
import com.herisand.submissionjp.databinding.ActivityDetailMovieBinding
import com.herisand.submissionjp.databinding.ContentDetailBinding
import com.herisand.submissionjp.utils.ApiConfig
import com.herisand.submissionjp.utils.year
import com.herisand.submissionjp.viewmodel.DetailViewModel
import com.herisand.submissionjp.viewmodel.ViewModelFactory
import kotlinx.android.synthetic.main.activity_detail_movie.*

class DetailMovieActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
    }

    private lateinit var detailBinding: ContentDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val activityDetailMovieBinding = ActivityDetailMovieBinding.inflate(layoutInflater)
        detailBinding = activityDetailMovieBinding.detailMovieContent
        setContentView(activityDetailMovieBinding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance(this)
        val viewModel = ViewModelProvider(this, factory)[DetailViewModel::class.java]

        val extras = intent.getParcelableExtra<MovieData>(EXTRA_MOVIE)
        extras?.let {
            activityDetailMovieBinding.progressBar.visibility = View.VISIBLE
            activityDetailMovieBinding.content.visibility = View.INVISIBLE
            viewModel.getMovie().observe(this, { movies ->
                activityDetailMovieBinding.progressBar.visibility = View.GONE
                activityDetailMovieBinding.content.visibility = View.VISIBLE

            })

            viewModel.getMovie().observe(this, {movie -> populateMovie(it)})
        }

    }

    private fun populateMovie(movieData: MovieData) {
        supportActionBar?.title = movieData.title
        detailBinding.tvTitleDetail.text = movieData.title
        detailBinding.tvYearDetail.text = movieData.year.year()
        detailBinding.tvDescriptionDetail.text = movieData.description
        detailBinding.ratDetail.rating = (movieData.scores.div(2)).toFloat()

        Glide.with(this)
            .load(ApiConfig.IMG_URL + movieData.background)
            .centerCrop()
            .into(bg_img)

        Glide.with(this)
            .load(ApiConfig.IMG_URL + movieData.image)
            .transform(RoundedCorners(20))
            .into(detailBinding.imgDetail)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return super.onOptionsItemSelected(item)
    }
}