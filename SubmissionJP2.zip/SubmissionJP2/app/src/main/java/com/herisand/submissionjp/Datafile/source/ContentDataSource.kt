package com.herisand.submissionjp.Datafile.source

import androidx.lifecycle.LiveData
import com.herisand.submissionjp.Datafile.source.remote.response.GenreMovie
import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
import com.herisand.submissionjp.Datafile.source.remote.response.TvData

interface ContentDataSource {

    fun getAllMovies(): LiveData<List<MovieData>>

    fun getAllTvShows(): LiveData<List<TvData>>

    fun getAllGenreMovie(): List<GenreMovie>

}