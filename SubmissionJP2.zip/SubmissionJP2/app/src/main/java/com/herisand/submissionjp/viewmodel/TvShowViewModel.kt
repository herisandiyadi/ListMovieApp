package com.herisand.submissionjp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.herisand.submissionjp.Datafile.source.ContentRepository
import com.herisand.submissionjp.Datafile.source.remote.response.TvData

class TvShowViewModel(private val contentRepository: ContentRepository): ViewModel() {
    fun getTvShow(): LiveData<List<TvData>> = contentRepository.getAllTvShows()
}