package com.herisand.submissionjp.Datafile.source.remote.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MovieData(
    var id: String,
    var title: String,
    var image: String,
    var description: String,
    var scores: Double,
    var year: String,
    var background: String
):Parcelable


