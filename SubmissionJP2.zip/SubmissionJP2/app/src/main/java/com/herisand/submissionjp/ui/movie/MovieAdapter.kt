package com.herisand.submissionjp.ui.movie

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
import com.herisand.submissionjp.databinding.ItemsMovieBinding
import com.herisand.submissionjp.ui.detail.DetailMovieActivity
import com.herisand.submissionjp.ui.detail.DetailMovieActivity.Companion.EXTRA_MOVIE
import com.herisand.submissionjp.utils.ApiConfig
import com.herisand.submissionjp.utils.year


class MovieAdapter: RecyclerView.Adapter<MovieAdapter.ListViewHolder>() {
    private var listMovie = ArrayList<MovieData>()


    fun setMovies(movies: List<MovieData>?) {
        if (movies == null) return
        this.listMovie.clear()
        this.listMovie.addAll(movies)
    }

    class ListViewHolder(private val binding: ItemsMovieBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(movie: MovieData) {
            with(binding) {
                Log.d("dataMovie", movie.toString())
                tvTitle.text = movie.title
//                tvGenre.text = movie.genre
                tvYear.text = movie.year.year()
                ratMovie.rating = (movie.scores.div(2)).toFloat()
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailMovieActivity::class.java)
                    intent.putExtra(EXTRA_MOVIE, movie)
                    itemView.context.startActivity(intent)
                }

                Glide.with(itemView.context)
                    .load(ApiConfig.IMG_URL + movie.image)
                    .apply(RequestOptions().override(220, 330))
                    .into(imgPoster)
            }

        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val itemsMovieBinding = ItemsMovieBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(itemsMovieBinding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val movie = listMovie[position]
        holder.bind(movie)
    }

    override fun getItemCount(): Int = listMovie.size
}