package com.herisand.submissionjp.Datafile.source.remote


import android.os.Handler
import android.os.Looper
import com.herisand.submissionjp.Datafile.source.remote.response.GenreMovie
import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
import com.herisand.submissionjp.Datafile.source.remote.response.TvData
import com.herisand.submissionjp.utils.EspressoIdlingResource
import com.herisand.submissionjp.utils.JsonHelper


class RemoteDataSource private constructor(private val jsonHelper: JsonHelper){

    private  val handler = Handler(Looper.getMainLooper())

    companion object {
        private const val SERVICE_LATENCY_IN_MILLIS:Long = 2000

        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(helper: JsonHelper): RemoteDataSource =
            instance ?: synchronized(this) {
                instance ?: RemoteDataSource(helper)
            }
    }

    fun getAllMovie(callback: LoadMovieCallback) {
        EspressoIdlingResource.increment()
        handler.postDelayed({callback.onAllMoviesReceived(jsonHelper.loadMovie())
                            EspressoIdlingResource.decrement()}, SERVICE_LATENCY_IN_MILLIS)
    }

    fun getAllTv(callback: LoadTvShowCallback) {
        EspressoIdlingResource.increment()
        handler.postDelayed({
            callback.onAllTvShowsReceived(jsonHelper.loadTvShow())
            EspressoIdlingResource.decrement() }, SERVICE_LATENCY_IN_MILLIS)
    }

    fun getAllGenreMovie(): List<GenreMovie> = jsonHelper.loadGenreMovie()

    interface LoadMovieCallback {
        fun onAllMoviesReceived(movieData: List<MovieData>)
    }

    interface LoadTvShowCallback {
        fun onAllTvShowsReceived(tvData: List<TvData>)
    }
}