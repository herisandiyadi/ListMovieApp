package com.herisand.submissionjp.Datafile.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.herisand.submissionjp.Datafile.source.remote.RemoteDataSource
import com.herisand.submissionjp.Datafile.source.remote.response.GenreMovie
import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
import com.herisand.submissionjp.Datafile.source.remote.response.TvData

class ContentRepository private constructor(private val remoteDataSource: RemoteDataSource) : ContentDataSource {

   companion object {
       @Volatile
       private var instance: ContentRepository? = null

       fun getInstance(remoteData: RemoteDataSource): ContentRepository =
           instance ?: synchronized(this) {
               instance ?: ContentRepository(remoteData)
           }
   }

    override fun getAllMovies(): LiveData<List<MovieData>> {
        val movieResults = MutableLiveData<List<MovieData>>()
        remoteDataSource.getAllMovie(object  : RemoteDataSource.LoadMovieCallback{
            override fun onAllMoviesReceived(movieData: List<MovieData>) {
                val movieList = ArrayList<MovieData>()
                for (response in movieData) {
                    val movie = MovieData(
                        response.id,
                        response.title,
                        response.image,
                        response.description,
                        response.scores,
                        response.year,
                        response.background
                    )
                    movieList.add(movie)
                }
                movieResults.postValue(movieList)
            }

        })
        return movieResults
    }



    override fun getAllTvShows(): LiveData<List<TvData>> {
        val tvResults = MutableLiveData<List<TvData>>()
        remoteDataSource.getAllTv(object : RemoteDataSource.LoadTvShowCallback {
            override fun onAllTvShowsReceived(tvData: List<TvData>) {
                val tvList = ArrayList<TvData>()
                for (response in tvData) {
                    val tvShow = TvData(
                        response.id,
                        response.title,
                        response.image,
                        response.description,
                        response.scores,
                        response.year,
                        response.background
                    )
                    tvList.add(tvShow)
                }
                tvResults.postValue(tvList)
            }
        })
       return tvResults
    }

    override fun getAllGenreMovie(): List<GenreMovie> {
        val genreMovieResponse = remoteDataSource.getAllGenreMovie()
        val genreList = ArrayList<GenreMovie>()
        for (response in genreMovieResponse) {
            val genreMovie = GenreMovie(
                response.id,
                response.name
            )
            genreList.add(genreMovie)
        }
        return genreList
    }

}