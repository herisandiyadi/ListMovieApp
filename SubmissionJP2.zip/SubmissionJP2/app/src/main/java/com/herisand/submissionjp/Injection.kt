package com.herisand.submissionjp

import android.content.Context
import com.herisand.submissionjp.Datafile.source.ContentRepository
import com.herisand.submissionjp.Datafile.source.remote.RemoteDataSource
import com.herisand.submissionjp.utils.JsonHelper

object Injection {

    fun provideRepository(context: Context): ContentRepository {
        val remoteDataSource = RemoteDataSource.getInstance(JsonHelper(context))

        return ContentRepository.getInstance(remoteDataSource)
    }
}