package com.herisand.submissionjp.resources

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}