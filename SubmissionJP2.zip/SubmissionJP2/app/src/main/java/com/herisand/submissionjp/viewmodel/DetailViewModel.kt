package com.herisand.submissionjp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.herisand.submissionjp.Datafile.source.ContentRepository
import com.herisand.submissionjp.Datafile.source.remote.response.MovieData
import com.herisand.submissionjp.Datafile.source.remote.response.TvData


class DetailViewModel(private  val contentRepository: ContentRepository): ViewModel() {

    private lateinit var id: String

    fun setSelectedContent(id: String) {
        this.id = id
    }

   fun getMovie(): LiveData<List<MovieData>> = contentRepository.getAllMovies()

    fun getTvShow(): LiveData<List<TvData>> = contentRepository.getAllTvShows()


}