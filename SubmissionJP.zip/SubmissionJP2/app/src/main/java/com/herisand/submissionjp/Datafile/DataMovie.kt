package com.herisand.submissionjp.Datafile

import com.herisand.submissionjp.R

object DataMovie {

    fun generateDataMovie(): List<MovieData> {
        val movie = ArrayList<MovieData>()

        movie.add(
            MovieData("mv1","A Start is Born",
            R.drawable.mv_poster_a_start_is_born,
        "A musician helps a young singer find fame as age and alcoholism send his own career into a downward spiral.",
            "2018",
            7.6,
            "Drama, Music, Romance",
            false)
        )
        movie.add(
            MovieData("mv2","Alita",
            R.drawable.mv_poster_alita,
            "When Alita awakens with no memory of who she is in a future world she does not recognize, she is taken in by Ido, a compassionate doctor who realizes that somewhere in this abandoned cyborg shell is the heart and soul of a young woman with an extraordinary past.",
            "2019",
            7.2,
            "Action, Adventure, Sci-Fi",
            false)
        )
        movie.add(
            MovieData("mv3","Aquaman",
            R.drawable.mv_poster_aquaman,
            "Once home to the most advanced civilization on Earth, Atlantis is now an underwater kingdom ruled by the power-hungry King Orm. With a vast army at his disposal, Orm plans to conquer the remaining oceanic people and then the surface world. Standing in his way is Arthur Curry, Orm's half-human, half-Atlantean brother and true heir to the throne.",
            "2018",
            6.9,
            "Action, Adventure, Fantasy",
            false)
        )
        movie.add(
            MovieData("mv4","Bohemian Rhapsody",
            R.drawable.mv_poster_bohemian,
            "Singer Freddie Mercury, guitarist Brian May, drummer Roger Taylor and bass guitarist John Deacon take the music world by storm when they form the rock 'n' roll band Queen in 1970. Hit songs become instant classics. When Mercury's increasingly wild lifestyle starts to spiral out of control, Queen soon faces its greatest challenge yet – finding a way to keep the band together amid the success and excess.",
            "2018",
            8.0,
            "Music, Drama, History",
            false)
        )
        movie.add(
            MovieData("mv5","Cold Persuit",
            R.drawable.mv_poster_cold_persuit,
            "A grieving snowplow driver seeks out revenge against the drug dealers who killed his son.",
            "2018",
            6.2,
            "Action, Crime, Drama",
            false)
        )
        movie.add(
            MovieData("mv6","Creed",
            R.drawable.mv_poster_creed,
            "The former World Heavyweight Champion Rocky Balboa serves as a trainer and mentor to Adonis Johnson, the son of his late friend and former rival Apollo Creed.",
            "2015",
            7.4,
            "Drama",
            false)
        )
        movie.add(
            MovieData("mv7","The Crimes of The Grindwald",
            R.drawable.mv_poster_crimes,
            "Gellert Grindelwald has escaped imprisonment and has begun gathering followers to his cause—elevating wizards above all non-magical beings. The only one capable of putting a stop to him is the wizard he once called his closest friend, Albus Dumbledore. However, Dumbledore will need to seek help from the wizard who had thwarted Grindelwald once before, his former student Newt Scamander, who agrees to help, unaware of the dangers that lie ahead. Lines are drawn as love and loyalty are tested, even among the truest friends and family, in an increasingly divided wizarding world.",
            "2018",
            6.9,
            "Adventure, Fantasy, Drama",
            false)
        )
        movie.add(
            MovieData("mv8","Glass",
            R.drawable.mv_poster_glass,
            "In a series of escalating encounters, former security guard David Dunn uses his supernatural abilities to track Kevin Wendell Crumb, a disturbed man who has twenty-four personalities. Meanwhile, the shadowy presence of Elijah Price emerges as an orchestrator who holds secrets critical to both men.",
            "2019",
            6.6,
            "Thriller, Drama, Science Fiction",
            false)
        )
        movie.add(
            MovieData("mv9","How to Train The Dragon",
            R.drawable.mv_poster_how_to_train,
            "As the son of a Viking leader on the cusp of manhood, shy Hiccup Horrendous Haddock III faces a rite of passage: he must kill a dragon to prove his warrior mettle. But after downing a feared dragon, he realizes that he no longer wants to destroy it, and instead befriends the beast – which he names Toothless – much to the chagrin of his warrior father",
            "2010",
            7.8,
            "Fantasy, Adventure, Animation, Family",
            false)
        )
        movie.add(
            MovieData("mv10","Avengers Infinity Wars",
            R.drawable.mv_poster_infinity_war,
            "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.",
            "2018",
            8.3,
            "Adventure, Action, Science Fiction",
            false)
        )
        movie.add(
            MovieData("mv11","Mary Queen of The Scots",
            R.drawable.mv_poster_marry_queen,
            "In 1561, Mary Stuart, widow of the King of France, returns to Scotland, reclaims her rightful throne and menaces the future of Queen Elizabeth I as ruler of England, because she has a legitimate claim to the English throne. Betrayals, rebellions, conspiracies and their own life choices imperil both Queens. They experience the bitter cost of power, until their tragic fate is finally fulfilled.",
            "2018",
            6.6,
            "Drama, History",
            false)
        )
        movie.add(
            MovieData("mv12","Master Z",
            R.drawable.mv_poster_master_z,
            "Following his defeat by Master Ip, Cheung Tin Chi tries to make a life with his young son in Hong Kong, waiting tables at a bar that caters to expats. But it's not long before the mix of foreigners, money, and triad leaders draw him once again to the fight.",
            "2018",
            5.7,
            "Action",
            false)
        )
        movie.add(
            MovieData("mv13","Mortal Engines",
            R.drawable.mv_poster_mortal_engines,
            "Many thousands of years in the future, Earth’s cities roam the globe on huge wheels, devouring each other in a struggle for ever diminishing resources. On one of these massive traction cities, the old London, Tom Natsworthy has an unexpected encounter with a mysterious young woman from the wastelands who will change the course of his life forever.",
            "2018",
            6.1,
            "Adventure, Science Fiction",
            false)
        )
        movie.add(
            MovieData("mv14","Overlord",
            R.drawable.mv_poster_overlord,
            "France, June 1944. On the eve of D-Day, some American paratroopers fall behind enemy lines after their aircraft crashes while on a mission to destroy a radio tower in a small village near the beaches of Normandy. After reaching their target, the surviving paratroopers realise that, in addition to fighting the Nazi troops that patrol the village, they also must fight against something else.",
            "2018",
            6.7,
            "Horror, War, Science Fiction",
            false)
        )
        movie.add(
            MovieData("mv15","Ralph Break The Internet",
            R.drawable.mv_poster_ralph,
            "Video game bad guy Ralph and fellow misfit Vanellope von Schweetz must risk it all by traveling to the World Wide Web in search of a replacement part to save Vanellope's video game, Sugar Rush. In way over their heads, Ralph and Vanellope rely on the citizens of the internet — the netizens — to help navigate their way, including an entrepreneur named Yesss, who is the head algorithm and the heart and soul of trend-making site BuzzzTube.",
            "2018",
            7.2,
            "Family, Animation, Comedy, Adventure",
            false)
        )
        movie.add(
            MovieData("mv16","Robin Hood",
            R.drawable.mv_poster_robin_hood,
            "A war-hardened Crusader and his Moorish commander mount an audacious revolt against the corrupt English crown",
             "2018",
             5.9,
             "Adventure, Action, Thriller",
             false)
        )
        movie.add(
            MovieData("mv17","Serenity",
            R.drawable.mv_poster_serenity,
            "The quiet life of Baker Dill, a fishing boat captain who lives on the isolated Plymouth Island, where he spends his days obsessed with capturing an elusive tuna while fighting his personal demons, is interrupted when someone from his past comes to him searching for help.",
            "2019",
            5.4,
            "Thriller, Mystery, Drama",
            false)
        )
        movie.add(
            MovieData("mv18","Spiderman: Into The Spider-Verse",
            R.drawable.mv_poster_spiderman,
            "Miles Morales is juggling his life between being a high school student and being a spider-man. When Wilson \"Kingpin\" Fisk uses a super collider, others from across the Spider-Verse are transported to this dimension.",
            "2018",
            8.4,
            "Action, Adventure, ANimation, ScienceFiction, Comedy",
            false)
        )
        movie.add(
            MovieData("mv19","T34",
            R.drawable.mv_poster_t34,
            "In 1944, a courageous group of Russian soldiers managed to escape from German captivity in a half-destroyed legendary T-34 tank. Those were the times of unforgettable bravery, fierce fighting, unbreakable love, and legendary miracles.",
            "2018",
            6.8,
            "War Action, Drama, History",
            false)
        )
        return movie
    }


}