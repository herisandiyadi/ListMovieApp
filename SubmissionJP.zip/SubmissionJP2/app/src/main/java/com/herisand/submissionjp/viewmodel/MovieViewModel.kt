package com.herisand.submissionjp.viewmodel

import androidx.lifecycle.ViewModel
import com.herisand.submissionjp.Datafile.DataMovie
import com.herisand.submissionjp.Datafile.MovieData

class MovieViewModel: ViewModel() {

    fun getMovie(): List<MovieData> = DataMovie.generateDataMovie()
}