package com.herisand.submissionjp.viewmodel

import androidx.lifecycle.ViewModel
import com.herisand.submissionjp.Datafile.DataMovie
import com.herisand.submissionjp.Datafile.DataTv
import com.herisand.submissionjp.Datafile.MovieData
import com.herisand.submissionjp.Datafile.TvData


class DetailViewModel: ViewModel() {

   private lateinit var id: String

   fun setSelectedItem(id: String) {
      this.id = id
   }

   fun getMovie(): MovieData {
      val cropped = id.chunked(2)
      val idMovie = "mv"
      lateinit var movieData: MovieData

      val items = when {
         cropped[0] == idMovie -> {
            DataMovie.generateDataMovie()
         }

         else -> {
            emptyList()
         }

      }

      if (!items.isNullOrEmpty()) {
         for (item in items) {
            if (item.id == id) {
               movieData = item
               break
            }
         }
      }
      return movieData

   }

   fun getTv(): TvData {
      val cropped = id.chunked(2)
      val idTv = "tv"

      lateinit var tvData: TvData

      val tvItems = when {
         cropped[0] == idTv -> {
            DataTv.generateDataTv()
         }

         else -> {
            emptyList()
         }
      }

      if (!tvItems.isNullOrEmpty()) {
         for (tvItem in tvItems) {
            if (tvItem.id == id) {
               tvData = tvItem
               break
            }
         }
      }
      return tvData

   }

}