package com.herisand.submissionjp.viewmodel

import androidx.lifecycle.ViewModel
import com.herisand.submissionjp.Datafile.DataTv
import com.herisand.submissionjp.Datafile.TvData

class TvShowViewModel: ViewModel() {
    fun getTvShow(): List<TvData> = DataTv.generateDataTv()
}