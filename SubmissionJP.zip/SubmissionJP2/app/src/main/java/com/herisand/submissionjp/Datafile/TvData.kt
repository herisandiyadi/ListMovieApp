package com.herisand.submissionjp.Datafile

data class TvData(
        var id: String,
        var title: String,
        var image: Int,
        var description: String,
        var year: String,
        var scores: Double,
        var genre: String,
        var bookmarked: Boolean= false
)
