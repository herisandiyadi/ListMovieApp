package com.herisand.submissionjp.ui.tvshows

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.herisand.submissionjp.Datafile.TvData
import com.herisand.submissionjp.databinding.ItemsTvshowsBinding
import com.herisand.submissionjp.ui.detail.DetailTvActivity

class TvAdapter: RecyclerView.Adapter<TvAdapter.ListViewHolder>() {
    private var listTvShow = ArrayList<TvData>()

    fun setTvShow(tvShows: List<TvData>?) {
        if (tvShows == null) return
        this.listTvShow.clear()
        this.listTvShow.addAll(tvShows)
    }

    class ListViewHolder(private val binding: ItemsTvshowsBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(tvData : TvData) {
            with(binding) {
                tvTitletv.text = tvData.title
                tvGenretv.text = tvData.genre
                tvYeartv.text = tvData.year
                ratTv.rating = (tvData.scores.div(2)).toFloat()
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailTvActivity::class.java)
                    intent.putExtra(DetailTvActivity.EXTRA_TV, tvData.id)
                    itemView.context.startActivity(intent)
                }

                Glide.with(itemView.context)
                        .load(tvData.image)
                        .apply(RequestOptions().override(220, 330))
                        .into(binding.imgPostertv)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val itemsTvshowsBinding = ItemsTvshowsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(itemsTvshowsBinding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val tvshows = listTvShow[position]
        holder.bind(tvshows)
    }

    override fun getItemCount(): Int = listTvShow.size
}