package com.herisand.submissionjp.ui.detail

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.herisand.submissionjp.Datafile.TvData
import com.herisand.submissionjp.R
import com.herisand.submissionjp.viewmodel.DetailViewModel
import kotlinx.android.synthetic.main.activity_detail_movie.*
import kotlinx.android.synthetic.main.content_detail.*


class DetailTvActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TV = "extra_tv"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_tv)

        val viewModelTV = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailViewModel::class.java]
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val extras = intent.extras
        extras?.let {
            val id = extras.getString(EXTRA_TV)
            id?.let {
                viewModelTV.setSelectedItem(it)
                populateMovie(viewModelTV.getTv())
            }
        }

    }

    private fun populateMovie(tvData: TvData) {
       tv_title_detail.text = tvData.title
        tv_year_detail.text = tvData.year
        tv_genre_detail.text = tvData.genre
        tv_description_detail.text = tvData.description
        supportActionBar?.title = tvData.title
        rat_detail.rating = (tvData.scores.div(2)).toFloat()
        bg_img.setImageResource(tvData.image)


        Glide.with(this)
            .load(tvData.image)
            .transform(RoundedCorners(20))
            .into(img_detail)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return super.onOptionsItemSelected(item)
    }

}