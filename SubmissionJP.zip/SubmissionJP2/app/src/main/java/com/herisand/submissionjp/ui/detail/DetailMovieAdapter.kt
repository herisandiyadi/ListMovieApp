package com.herisand.submissionjp.ui.detail

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.herisand.submissionjp.Datafile.MovieData
import com.herisand.submissionjp.databinding.ContentDetailBinding


class DetailMovieAdapter: RecyclerView.Adapter<DetailMovieAdapter.ViewHolder>() {

    private val detailMovie = ArrayList<MovieData>()

    fun setMovies(movies: List<MovieData>?) {
        if (movies == null) return
        this.detailMovie.clear()
        this.detailMovie.addAll(movies)
    }

    inner class ViewHolder(private val binding: ContentDetailBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(movie : MovieData) {
            binding.tvTitleDetail.text = movie.title
            binding.tvYearDetail.text = movie.year
            binding.tvGenreDetail.text = movie.genre
            binding.tvDescriptionDetail.text = movie.description

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val contentDetailBinding = ContentDetailBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(contentDetailBinding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val movie = detailMovie[position]
        holder.bind(movie)
    }

    override fun getItemCount(): Int = detailMovie.size

}