package com.herisand.submissionjp.Datafile

import com.herisand.submissionjp.R

object DataTv {
    fun generateDataTv(): List<TvData> {
        val tvshow = ArrayList<TvData>()

        tvshow.add(
                TvData("tv1","Arrow",
                        R.drawable.poster_arrow,
                        "Spoiled billionaire playboy Oliver Queen is missing and presumed dead when his yacht is lost at sea. He returns five years later a changed man, determined to clean up the city as a hooded vigilante armed with a bow.",
                        "2012",
                        6.6,
                        "Crime, Drama, Mystery, Action & Adventure",
                        false)
        )
        tvshow.add(
                TvData("tv2","Doom Patrol",
                        R.drawable.poster_doom_patrol,
                        "The Doom Patrol’s members each suffered horrible accidents that gave them superhuman abilities — but also left them scarred and disfigured. Traumatized and downtrodden, the team found purpose through The Chief, who brought them together to investigate the weirdest phenomena in existence — and to protect Earth from what they find.",
                        "2019",
                        7.6,
                        "Sci-Fi & Fantasy, Action & Adventure, Comedy",
                        false)
        )
        tvshow.add(
                TvData("tv3","Dragon Ball",
                        R.drawable.poster_dragon_ball,
                        "Five years have passed since the fight with Piccolo Jr., and Goku now has a son, Gohan. The peace is interrupted when an alien named Raditz arrives on Earth in a spacecraft and tracks down Goku, revealing to him that that they are members of a near-extinct warrior race called the Saiyans.",
                        "1989",
                        8.2,
                        "Animation, Sci-Fi & Fantasy, Action & Adventure",
                        false)
        )
        tvshow.add(
                TvData("tv4","Fairy Tail",
                        R.drawable.poster_fairytail,
                        "Natsu Dragneel and his friends travel to the island Kingdom of Stella, where they will reveal dark secrets, fight the new enemies and once again save the world from destruction.",
                        "2017",
                        6.5,
                        "Action, Adventure, Comedy, Fantasy, Animation",
                        false)
        )
        tvshow.add(
                TvData("tv5","Family Guy",
                        R.drawable.poster_family_guy,
                        "Sick, twisted, politically incorrect and Freakin' Sweet animated series featuring the adventures of the dysfunctional Griffin family. Bumbling Peter and long-suffering Lois have three kids. Stewie (a brilliant but sadistic baby bent on killing his mother and taking over the world), Meg (the oldest, and is the most unpopular girl in town) and Chris (the middle kid, he's not very bright but has a passion for movies). The final member of the family is Brian - a talking dog and much more than a pet, he keeps Stewie in check whilst sipping Martinis and sorting through his own life issues.",
                        "1999",
                        6.9,
                        "Animation Comedy",
                        false)
        )
        tvshow.add(
                TvData("tv6","Flash",
                        R.drawable.poster_flash,
                        "After a particle accelerator causes a freak storm, CSI Investigator Barry Allen is struck by lightning and falls into a coma. Months later he awakens with the power of super speed, granting him the ability to move through Central City like an unseen guardian angel. Though initially excited by his newfound powers, Barry is shocked to discover he is not the only \"meta-human\" who was created in the wake of the accelerator explosion -- and not everyone is using their new powers for good. Barry partners with S.T.A.R. Labs and dedicates his life to protect the innocent. For now, only a few close friends and associates know that Barry is literally the fastest man alive, but it won't be long before the world learns what Barry Allen has become...The Flash.",
                        "2014",
                        7.6,
                        "Drama, Sci-Fi & Fantasy",
                        false)
        )
        tvshow.add(
                TvData("tv7","Got",
                        R.drawable.poster_god,
                        "Seven noble families fight for control of the mythical land of Westeros. Friction between the houses leads to full-scale war. All while a very ancient evil awakens in the farthest north. Amidst the war, a neglected military order of misfits, the Night's Watch, is all that stands between the realms of men and icy horrors beyond.",
                        "2011",
                        8.4,
                        "Sci-Fi & Fantasy, Drama, Action & Adventure",
                        false)
        )
        tvshow.add(
                TvData("tv8","Gotham",
                        R.drawable.poster_gotham,
                        "Everyone knows the name Commissioner Gordon. He is one of the crime world's greatest foes, a man whose reputation is synonymous with law and order. But what is known of Gordon's story and his rise from rookie detective to Police Commissioner? What did it take to navigate the multiple layers of corruption that secretly ruled Gotham City, the spawning ground of the world's most iconic villains? And what circumstances created them – the larger-than-life personas who would become Catwoman, The Penguin, The Riddler, Two-Face and The Joker?",
                        "2014",
                        7.5,
                        "Drama, Crime, Sci-Fi & Fantasy",
                        false)
        )
        tvshow.add(
                TvData("tv9","Grey's Anatomy",
                        R.drawable.poster_grey_anatomy,
                        "Follows the personal and professional lives of a group of doctors at Seattle’s Grey Sloan Memorial Hospital.",
                        "2005",
                        8.2,
                        "Drama",
                        false)
        )
        tvshow.add(
                TvData("tv10","Hanna",
                        R.drawable.poster_hanna,
                        "This thriller and coming-of-age drama follows the journey of an extraordinary young girl as she evades the relentless pursuit of an off-book CIA agent and tries to unearth the truth behind who she is. Based on the 2011 Joe Wright film.",
                        "2019",
                        7.5,
                        "Action & Adventure, Drama",
                        false)
        )
        tvshow.add(
                TvData("tv11","Iron Fist",
                        R.drawable.poster_iron_fist,
                        "Danny Rand resurfaces 15 years after being presumed dead. Now, with the power of the Iron Fist, he seeks to reclaim his past and fulfill his destiny.",
                        "2017",
                        6.5,
                        "Action & Adventure, Drama, Sci-Fi & Fantasy",
                        false)
        )
        tvshow.add(
                TvData("tv12","Naruto Shipudden",
                        R.drawable.poster_naruto_shipudden,
                        "Naruto Shippuuden is the continuation of the original animated TV series Naruto.The story revolves around an older and slightly more matured Uzumaki Naruto and his quest to save his friend Uchiha Sasuke from the grips of the snake-like Shinobi, Orochimaru. After 2 and a half years Naruto finally returns to his village of Konoha, and sets about putting his ambitions to work, though it will not be easy, as He has amassed a few (more dangerous) enemies, in the likes of the shinobi organization; Akatsuki.",
                        "2007",
                        8.6,
                        "Animation, Action & Adventure, Sci-Fi & Fantasy",
                        false)
        )
        tvshow.add(
                TvData("tv13","NCIS",
                        R.drawable.poster_ncis,
                        "From murder and espionage to terrorism and stolen submarines, a team of special agents investigates any crime that has a shred of evidence connected to Navy and Marine Corps personnel, regardless of rank or position.",
                        "2003",
                        7.3,
                        "Crime, Action & Adventure, Drama",
                        false)
        )
        tvshow.add(
                TvData("tv14","Riverdale",
                        R.drawable.poster_riverdale,
                        "Set in the present, the series offers a bold, subversive take on Archie, Betty, Veronica and their friends, exploring the surreality of small-town life, the darkness and weirdness bubbling beneath Riverdale’s wholesome facade.",
                        "2017",
                        8.6,
                        "Mystery, Drama, Crime",
                        false)
        )
        tvshow.add(
                TvData("tv15","Shameless",
                        R.drawable.poster_shameless,
                        "Chicagoan Frank Gallagher is the proud single dad of six smart, industrious, independent kids, who without him would be... perhaps better off. When Frank's not at the bar spending what little money they have, he's passed out on the floor. But the kids have found ways to grow up in spite of him. They may not be like any family you know, but they make no apologies for being exactly who they are.",
                        "2011",
                        7.9,
                        "Drama, Comedy",
                        false)
        )
        tvshow.add(
                TvData("tv16","Supergirl",
                        R.drawable.poster_supergirl,
                        "Twenty-four-year-old Kara Zor-El, who was taken in by the Danvers family when she was 13 after being sent away from Krypton, must learn to embrace her powers after previously hiding them. The Danvers teach her to be careful with her powers, until she has to reveal them during an unexpected disaster, setting her on her journey of heroism.",
                        "2015",
                        7.2,
                        "Drama, Sci-Fi & Fantasy, Action & Adventure",
                        false)
        )
        tvshow.add(
                TvData("tv17","Supernatural",
                        R.drawable.poster_supernatural,
                        "When they were boys, Sam and Dean Winchester lost their mother to a mysterious and demonic supernatural force. Subsequently, their father raised them to be soldiers. He taught them about the paranormal evil that lives in the dark corners and on the back roads of America ... and he taught them how to kill it. Now, the Winchester brothers crisscross the country in their '67 Chevy Impala, battling every kind of supernatural threat they encounter along the way.",
                        "2005",
                        8.2,
                        "Drama, Mystery, Sci-Fi & Fantasy",
                        false)
        )
        tvshow.add(
                TvData("tv18","The Simpson",
                        R.drawable.poster_the_simpson,
                        "Set in Springfield, the average American town, the show focuses on the antics and everyday adventures of the Simpson family; Homer, Marge, Bart, Lisa and Maggie, as well as a virtual cast of thousands. Since the beginning, the series has been a pop culture icon, attracting hundreds of celebrities to guest star. The show has also made name for itself in its fearless satirical take on politics, media and American life in general.",
                        "1989",
                        7.8,
                        "Family, Animation, Comedy",
                        false)
        )
        tvshow.add(
                TvData("tv19","The Umbrella Academy",
                        R.drawable.poster_the_umbrella,
                        "A dysfunctional family of superheroes comes together to solve the mystery of their father's death, the threat of the apocalypse and more.",
                        "2019",
                        8.7,
                        "Action & Adventure, Sci-Fi & Fantasy, Drama",
                        false)
        )
        tvshow.add(
                TvData("tv20","The Walking Dead",
                        R.drawable.poster_the_walking_dead,
                        "Sheriff's deputy Rick Grimes awakens from a coma to find a post-apocalyptic world dominated by flesh-eating zombies. He sets out to find his family and encounters many other survivors along the way.",
                        "2010",
                        8.0,
                        "Action & Adventure, Drama, Sci-Fi & Fantasy",
                        false)
        )
        return tvshow
    }
}