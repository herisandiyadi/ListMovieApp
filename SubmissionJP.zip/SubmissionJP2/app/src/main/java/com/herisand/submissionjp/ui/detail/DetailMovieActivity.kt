package com.herisand.submissionjp.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.herisand.submissionjp.Datafile.MovieData
import com.herisand.submissionjp.R
import com.herisand.submissionjp.viewmodel.DetailViewModel
import kotlinx.android.synthetic.main.activity_detail_movie.*
import kotlinx.android.synthetic.main.content_detail.*


class DetailMovieActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_movie)

        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailViewModel::class.java]

        val extra = intent.extras

        extra?.let{
            val id = extra.getString(EXTRA_MOVIE)
            id?.let {
                viewModel.setSelectedItem(it)
                populateMovie(viewModel.getMovie())
            }
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

    }

    private fun populateMovie(movieData: MovieData) {
        Log.d("movieData", movieData.toString())
        tv_title_detail.text = movieData.title
        tv_year_detail.text = movieData.year
        tv_genre_detail.text = movieData.genre
        tv_description_detail.text = movieData.description
        rat_detail.rating = (movieData.scores.div(2)).toFloat()
        supportActionBar?.title = movieData.title
        bg_img.setImageResource(movieData.image)

        Glide.with(this)
            .load(movieData?.image)
            .transform(RoundedCorners(30))
            .into(img_detail)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) finish()
        return super.onOptionsItemSelected(item)
    }
}