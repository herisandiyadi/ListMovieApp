package com.herisand.submissionjp.ui.home

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.herisand.submissionjp.Datafile.DataMovie
import com.herisand.submissionjp.Datafile.DataTv
import com.herisand.submissionjp.R
import org.junit.Rule
import org.junit.Test


class MainActivityTest {

    private val dataMovie = DataMovie.generateDataMovie()
    private val dataTv = DataTv.generateDataTv()

    @get:Rule
    var activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun fPager(){
        onView(withId(R.id.view_pager)).perform(swipeLeft())
        onView(withId(R.id.view_pager)).perform(swipeRight())
    }

    @Test
    fun loadRVMovie(){
        onView(withId(R.id.rv_movie)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_movie)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dataMovie.size))
        onView(withId(R.id.rv_movie)).perform(swipeUp())
    }

    @Test
    fun loadDetailMovie(){
        onView(withId(R.id.rv_movie)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        Thread.sleep(500)
        onView(withId(R.id.tv_title_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_title_detail)).check(matches(withText(dataMovie[0].title)))
        onView(withId(R.id.img_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_genre_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_genre_detail)).check(matches(withText(dataMovie[0].genre)))
        onView(withId(R.id.tv_year_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_year_detail)).check(matches(withText(dataMovie[0].year)))
        onView(withId(R.id.tv_description_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_description_detail)).check(matches(withText(dataMovie[0].description)))
        onView(withId(R.id.rat_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.bg_img)).check(matches(isDisplayed()))
        Thread.sleep(500)
    }

    @Test
    fun loadRVTV(){
        pressBack()
        onView(withId(R.id.view_pager)).perform(swipeLeft())
        onView(withId(R.id.rv_tvshows)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_tvshows)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dataTv.size))
        Thread.sleep(500)
    }

    @Test
    fun loadDetailTV(){
        onView(withText("TV SHOWS")).perform(click())
        Thread.sleep(500)
        onView(withId(R.id.rv_tvshows)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        Thread.sleep(500)
        onView(withId(R.id.tv_title_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_title_detail)).check(matches(withText(dataTv[0].title)))
        onView(withId(R.id.img_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_genre_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_genre_detail)).check(matches(withText(dataTv[0].genre)))
        onView(withId(R.id.tv_year_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_year_detail)).check(matches(withText(dataTv[0].year)))
        onView(withId(R.id.tv_description_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_description_detail)).check(matches(withText(dataTv[0].description)))
        onView(withId(R.id.rat_detail)).check(matches(isDisplayed()))
        onView(withId(R.id.bg_img)).check(matches(isDisplayed()))
        Thread.sleep(500)
        pressBack()

    }

}