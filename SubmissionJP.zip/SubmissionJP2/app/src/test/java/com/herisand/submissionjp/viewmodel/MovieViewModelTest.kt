package com.herisand.submissionjp.viewmodel

import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class MovieViewModelTest{

    private lateinit var viewModel: MovieViewModel

    @Before
    fun setMovie(){
        viewModel = MovieViewModel()
    }

    @Test
    fun getMovie() {
        val movieData = viewModel.getMovie()
        assertNotNull(movieData)
        assertEquals(19, movieData.size)
    }
}