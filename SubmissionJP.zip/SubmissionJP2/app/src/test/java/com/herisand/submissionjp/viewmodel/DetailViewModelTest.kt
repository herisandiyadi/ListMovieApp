package com.herisand.submissionjp.viewmodel

import com.herisand.submissionjp.Datafile.DataMovie
import com.herisand.submissionjp.Datafile.DataTv
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException
import kotlin.jvm.Throws

class DetailViewModelTest{

    private lateinit var viewModel: DetailViewModel
    private val dataMovie = DataMovie.generateDataMovie()[0]
    private val selectedMovie = dataMovie.id
    private val dataTv = DataTv.generateDataTv()[0]
    private val selectedTv = dataTv.id
    private val selectedMovieNotExist = "mv20"
    private val selectedTvNotExist = "tv21"

    @get:Rule
    var thrown: ExpectedException = ExpectedException.none()

    @Before
    fun setUp() {
        viewModel = DetailViewModel()
        viewModel.setSelectedItem(selectedMovie)
        viewModel.setSelectedItem(selectedTv)
    }

    @Test
    fun getMovie() {
        viewModel.setSelectedItem(selectedMovie)
        val mvData = viewModel.getMovie()
        assertNotNull(dataMovie)
        assertEquals(dataMovie.id, mvData.id)
        assertEquals(dataMovie.title, mvData.title)
        assertEquals(dataMovie.image, mvData.image)
        assertEquals(dataMovie.genre, mvData.genre)
        assertEquals(dataMovie.year, mvData.year)
        assertEquals(dataMovie.description, mvData.description)
    }

    @Test
    fun setSelectedItem() {
        assertNotNull(selectedMovie)
        assertNotNull(selectedTv)
    }

    @Test
    fun getTv() {
        viewModel.setSelectedItem(selectedTv)
        val tvData = viewModel.getTv()
        assertNotNull(dataTv)
        assertEquals(dataTv.id, tvData.id)
        assertEquals(dataTv.year, tvData.year)
        assertEquals(dataTv.title, tvData.title)
        assertEquals(dataTv.image, tvData.image)
        assertEquals(dataTv.genre, tvData.genre)
        assertEquals(dataTv.description, tvData.description)
    }

    @Test
    @Throws(UninitializedPropertyAccessException::class)
    fun getMovieNotExist() {
        viewModel.setSelectedItem(selectedMovieNotExist)
        thrown.expect(UninitializedPropertyAccessException::class.java)
        val movieData = viewModel.getMovie()
        assertNotNull(movieData)
        assertEquals(dataMovie.id, movieData.id)
    }

    @Test
    @Throws(UninitializedPropertyAccessException::class)
    fun getTvNotExist() {
        viewModel.setSelectedItem(selectedTvNotExist)
        thrown.expect(UninitializedPropertyAccessException::class.java)
        val tvData = viewModel.getTv()
        assertNotNull(tvData)
        assertEquals(dataMovie.id, tvData.id)
    }

}