package com.herisand.submissionjp.viewmodel

import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel

    @Before
    fun setTvShow(){
        viewModel = TvShowViewModel()
    }

    @Test
    fun getTvShow() {
        val tvData = viewModel.getTvShow()
        assertNotNull(tvData)
        assertEquals(20, tvData.size)
    }

}